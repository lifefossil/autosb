package ${basePackage};

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ${ApplicationName} {

    public static void main(String[] args) {
        SpringApplication.run(${ApplicationName}.class, args);
    }

}
